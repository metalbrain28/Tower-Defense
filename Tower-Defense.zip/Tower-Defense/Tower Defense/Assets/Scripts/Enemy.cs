﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour {

     public GameObject[] waypoints;
     public int life ;
     public float speed = 0.5f;
     public int targetWaypoint;
     public bool isBoss = false;
    
    // Use this for initialization
    void Start () {
         if (isBoss == true)
             life = 5;
         else
             life = 3;
        this.transform.position = waypoints[0].transform.position;
     

}
     
    // Update is called once per frame
    void Update () {
       
         float step = speed*Time.deltaTime ;
        if (targetWaypoint == 12)
            killed();
        else {
            transform.position = Vector3.MoveTowards(transform.position, waypoints[targetWaypoint].transform.position, step);
            if (gameObject.transform.position == waypoints[targetWaypoint].transform.position)
                targetWaypoint++;

        }
        
      
    }

	void killed(){
		//EnemyManager.Instance.enemies.Remove(this.gameObject);
		Destroy(this.gameObject);
	
	}
    private void move()
    {
        //float step = speed * Time.deltaTime;
       // transform.position = Vector2.MoveTowards(transform.position, waypoints[targetWaypoint].transform.position, step);
     transform.Translate(waypoints[1].transform.position * speed);
    }



}
